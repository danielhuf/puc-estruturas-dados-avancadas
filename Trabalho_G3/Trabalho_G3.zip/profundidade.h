#include "grafo.h"

int* buscaProfundidade(Grafo *g, int origem, int destino, int *cont);