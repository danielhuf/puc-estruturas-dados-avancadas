typedef struct aresta Aresta;

Aresta *kruskal(Grafo *g);