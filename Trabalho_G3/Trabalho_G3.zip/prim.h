typedef struct aresta Aresta;

Aresta *prim(Grafo *g);

int imprime_arv(Aresta *arv, Grafo *g, int col);