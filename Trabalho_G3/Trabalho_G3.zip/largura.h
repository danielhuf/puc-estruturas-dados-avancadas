#include "grafo.h"

int* buscaLargura(Grafo *g, int origem, int destino, int *cont);